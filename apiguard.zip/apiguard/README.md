# APIGuard

A real-time API security proxy. It sits in front of any HTTP API, inspects every
request **and response**, detects the vulnerability classes that cause most real
API breaches, and blocks, redacts, or throttles them live — with a console that
shows exactly what was flagged and why.

## The one idea

Most API security tools scan the **request** for suspicious text — SQL, script
tags, odd headers. But the vulnerabilities that actually leak data don't look
suspicious as text:

- A user requesting `GET /api/orders/1043` — a perfectly normal URL — when that
  order belongs to someone else (**BOLA**, the #1 API risk).
- An endpoint returning `password_hash` and `phone` in the JSON when the UI only
  shows a name (**excessive data exposure**) — the problem is in the *response*,
  which almost nothing inspects.

To catch these you have to know **who is asking** (read from the token) and look
at **what came back** (the response body). That is what APIGuard does and what a
traditional firewall structurally cannot.

## What it detects

| Detector | Catches | OWASP API Top 10 | Action |
|---|---|---|---|
| `ownership` | Cross-user object access + ID enumeration | API1 BOLA | block / throttle |
| `sensitive` | Secret fields & PII in responses | API3 Excessive Data Exposure | redact |
| `authrole` | `alg:none`, expired/missing token, admin access by non-admin | API2 Broken Auth, API5 BFLA | block |
| `abuse` | Request floods, oversized `?limit` scraping | API4 Resource Consumption | throttle |

## Run it (3 terminals)

Requires Python 3.10+.

```bash
pip install fastapi uvicorn httpx

# terminal 1 — the vulnerable target API being protected
python -m uvicorn target_api.app:app --port 9000

# terminal 2 — the APIGuard security proxy
python -m uvicorn gateway.proxy:app --port 8080

# terminal 3 — fire the scripted attacks through the proxy
python -m attack.simulate          # once
python -m attack.simulate --loop   # continuous, for a live demo
```

Then open the console at **http://127.0.0.1:8080**.

All traffic in the demo goes to the proxy on **8080**, never to the target on
9000 directly — that's the point: the guard is in the path.

## The console

- **Live feed** — every request, newest first, colour-coded by action. Click any
  row to expand the **evidence**: the exact fields, values, and counts that
  triggered the finding, with the OWASP category.
- **Enforcement mode** — `observe` (detect only), `warn` (flag, still pass), or
  `enforce` (act). This is how we manage false positives and developer friction:
  roll out in observe, tune, then enforce.
- **Trusted identities** — allow-list a caller the operator has judged a false
  positive. This is the "review or override its actions" requirement.
- **Discovered endpoints** — the inventory the proxy builds automatically from
  live traffic, with per-endpoint request and block counts.

## How it's built

```
client ── HTTP ──▶ APIGuard proxy ──▶ target API ──▶ proxy ──▶ client
                        │
                        ├─ decode token  → who is calling
                        ├─ run detectors → findings (request + response phase)
                        ├─ policy engine → decide action given mode + overrides
                        └─ record event  → console
```

One FastAPI process, four small modules:

- `gateway/proxy.py` — the reverse proxy, forwarding via `httpx`, timing each round trip.
- `gateway/detectors/` — one class per detector, all sharing a one-method interface.
- `gateway/policy.py` — turns findings into an action, honouring mode + overrides.
- `common/` — the shared `Event`/`Finding` data model and helpers.

Adding a detector = writing one class and registering it in
`gateway/detectors/__init__.py`. Nothing else changes.

See `ARCHITECTURE.md` for the full walkthrough and design trade-offs.

## Deliberate trade-offs (prototype scope)

These are conscious choices, documented rather than hidden:

1. **We decode JWTs but don't verify signatures.** Knowing the *claimed* identity
   is enough to demonstrate authorization detection. Production would verify
   against the issuer's key — a config change, not an architecture change.
2. **In-memory event store.** A `deque` ring buffer, no database. History resets
   on restart; irrelevant for real-time protection, and it keeps the code
   dependency-light. Swapping in SQLite/Postgres touches only `_record()`.
3. **Throttle is advisory.** It flags and records the abusive caller rather than
   dropping the connection, so the demo stays legible. Enforcing a hard 429 is a
   few lines in the proxy's action switch.
4. **We focused on authorization and data-exposure over injection.** SQLi/XSS are
   web-app problems largely solved by parameterised queries; the modern API
   breach is an authorization failure, so that's where depth went.
