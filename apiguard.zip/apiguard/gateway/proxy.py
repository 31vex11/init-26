"""
APIGuard - the security reverse proxy.

This is the centre of everything. Traffic flows:

    client  ->  THIS PROXY  ->  target API  ->  THIS PROXY  ->  client

At the proxy we:
  1. read the token to learn WHO is calling
  2. run request-phase detectors (can block before forwarding)
  3. forward to the real API and time the round trip
  4. run response-phase detectors on the body that came back
  5. ask the policy engine what to do, and do it (block/redact/throttle/allow)
  6. record an Event so the dashboard can show it

Run on port 8080. It forwards to the target API on port 9000 by default.
"""

import time
import os
from collections import deque

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response, FileResponse

from common.helpers import RequestContext, templatize, decode_jwt
from common.models import (Event, ACTION_ALLOW, ACTION_REDACT,
                           ACTION_THROTTLE, ACTION_BLOCK)
from gateway.detectors import ALL_DETECTORS
from gateway.detectors.sensitive import redact_body
from gateway.policy import Policy

# where the real API lives
UPSTREAM = os.environ.get("UPSTREAM", "http://127.0.0.1:9000")

app = FastAPI(title="APIGuard")
policy = Policy(mode="enforce")

# in-memory event log (newest last). A ring buffer so it can't grow forever.
EVENTS: deque[Event] = deque(maxlen=500)
# rolling endpoint inventory: endpoint -> stats
ENDPOINTS: dict[str, dict] = {}

client = httpx.AsyncClient(timeout=10.0)


def _record(ev: Event):
    EVENTS.append(ev)
    stat = ENDPOINTS.setdefault(ev.endpoint, {
        "endpoint": ev.endpoint, "requests": 0, "flagged": 0,
        "blocked": 0, "last_status": 0,
    })
    stat["requests"] += 1
    stat["last_status"] = ev.status
    if ev.findings:
        stat["flagged"] += 1
    if ev.action == ACTION_BLOCK:
        stat["blocked"] += 1


# ---- dashboard API (must be declared BEFORE the catch-all route) ------------
@app.get("/__guard/events")
async def guard_events():
    """Newest-first list of recent events for the live feed."""
    return JSONResponse([e.to_dict() for e in reversed(EVENTS)])


@app.get("/__guard/endpoints")
async def guard_endpoints():
    """The discovered endpoint inventory with per-endpoint counts."""
    return JSONResponse(list(ENDPOINTS.values()))


@app.get("/__guard/summary")
async def guard_summary():
    total = len(EVENTS)
    flagged = sum(1 for e in EVENTS if e.findings)
    blocked = sum(1 for e in EVENTS if e.action == ACTION_BLOCK)
    redacted = sum(1 for e in EVENTS if e.action == ACTION_REDACT)
    return {
        "mode": policy.mode,
        "overrides": sorted(policy.overrides),
        "total": total, "flagged": flagged,
        "blocked": blocked, "redacted": redacted,
        "endpoints": len(ENDPOINTS),
    }


@app.post("/__guard/mode")
async def guard_set_mode(request: Request):
    body = await request.json()
    policy.set_mode(body.get("mode", "enforce"))
    return {"mode": policy.mode}


@app.post("/__guard/override")
async def guard_override(request: Request):
    """Allow-list or un-allow-list an identity (the human override)."""
    body = await request.json()
    ident = body.get("identity", "")
    if body.get("clear"):
        policy.clear_override(ident)
    else:
        policy.add_override(ident)
    return {"overrides": sorted(policy.overrides)}


@app.get("/")
async def dashboard():
    """Serve the dashboard HTML."""
    here = os.path.dirname(__file__)
    return FileResponse(os.path.join(here, "static", "index.html"))


# ---- the catch-all proxy route ---------------------------------------------
@app.api_route("/{full_path:path}",
               methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def proxy(full_path: str, request: Request):
    started = time.time()
    raw_path = "/" + full_path

    # build the context detectors will read
    token = request.headers.get("authorization", "")
    claims = decode_jwt(token)
    ctx = RequestContext(
        method=request.method,
        path=raw_path,
        endpoint=templatize(raw_path),
        client_ip=request.client.host if request.client else "-",
        headers=dict(request.headers),
        query=dict(request.query_params),
        token=token,
        claims=claims,
        identity=claims.get("sub", "anonymous"),
        role=claims.get("role", "anonymous"),
    )

    findings = []

    # ---- phase 1: request-only detectors (can block before forwarding) ----
    for det in ALL_DETECTORS:
        # response detectors need a body; skip them here (status still 0)
        f = det.evaluate(ctx)
        if f:
            findings.append(f)

    early_action = policy.decide(findings, ctx.identity)
    if early_action == ACTION_BLOCK:
        ev = Event(method=ctx.method, path=ctx.path, endpoint=ctx.endpoint,
                   client_ip=ctx.client_ip, identity=ctx.identity, role=ctx.role,
                   status=403, latency_ms=round((time.time() - started) * 1000, 1),
                   findings=findings, action=ACTION_BLOCK, mode=policy.mode)
        _record(ev)
        return JSONResponse(
            {"error": "blocked by APIGuard",
             "reason": findings[0].title if findings else "policy",
             "event_id": ev.id},
            status_code=403)

    # ---- forward to the real API ------------------------------------------
    body = await request.body()
    url = UPSTREAM + raw_path
    try:
        upstream = await client.request(
            ctx.method, url, params=dict(request.query_params),
            headers={k: v for k, v in request.headers.items()
                     if k.lower() not in ("host", "content-length")},
            content=body,
        )
    except Exception as exc:
        ev = Event(method=ctx.method, path=ctx.path, endpoint=ctx.endpoint,
                   client_ip=ctx.client_ip, identity=ctx.identity, role=ctx.role,
                   status=502, latency_ms=round((time.time() - started) * 1000, 1),
                   findings=findings, action=ACTION_ALLOW, mode=policy.mode)
        _record(ev)
        return JSONResponse({"error": f"upstream unreachable: {exc}"},
                            status_code=502)

    # parse the response body for the response-phase detectors
    ctx.status = upstream.status_code
    ctx.response_text = upstream.text
    try:
        ctx.response_json = upstream.json()
    except Exception:
        ctx.response_json = None

    # ---- phase 2: response detectors (now that we have a body) ------------
    # re-run all detectors; response ones only fire now that status/body exist.
    # (request-phase ones already fired above and returned None or a finding;
    # running again is cheap and keeps the code simple. We de-dupe by title.)
    seen_titles = {f.title for f in findings}
    for det in ALL_DETECTORS:
        f = det.evaluate(ctx)
        if f and f.title not in seen_titles:
            findings.append(f)
            seen_titles.add(f.title)

    action = policy.decide(findings, ctx.identity)

    # ---- act on the decision ----------------------------------------------
    out_status = upstream.status_code
    out_content = upstream.content
    media = upstream.headers.get("content-type", "application/json")

    if action == ACTION_BLOCK:
        out_status = 403
        out_content = (b'{"error":"blocked by APIGuard"}')
        media = "application/json"
    elif action == ACTION_REDACT and ctx.response_json is not None:
        import json
        out_content = json.dumps(redact_body(ctx.response_json)).encode()
        media = "application/json"
    # THROTTLE / ALLOW: pass the body through unchanged (throttle is advisory
    # here; the finding is recorded and the caller is flagged on the dashboard)

    ev = Event(method=ctx.method, path=ctx.path, endpoint=ctx.endpoint,
               client_ip=ctx.client_ip, identity=ctx.identity, role=ctx.role,
               status=out_status,
               latency_ms=round((time.time() - started) * 1000, 1),
               findings=findings, action=action, mode=policy.mode)
    _record(ev)

    return Response(content=out_content, status_code=out_status, media_type=media)
