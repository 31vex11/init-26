"""
The detector registry.

This is the ONLY place detectors are wired in. To add a new detector: write
the class, import it here, add an instance to ALL_DETECTORS. Nothing else in
the codebase needs to change. That is the payoff of the shared Detector shape.

Order matters slightly: request-only detectors (authrole, abuse) can fire
before the upstream call; response detectors (ownership, sensitive) need the
body. The proxy handles both phases - see proxy.py.
"""

from .ownership import OwnershipDetector
from .sensitive import SensitiveDetector
from .authrole import AuthRoleDetector
from .abuse import AbuseDetector

# Instantiated once and reused, because several hold state (rate windows,
# enumeration history) that must persist across requests.
ALL_DETECTORS = [
    AuthRoleDetector(),
    AbuseDetector(),
    OwnershipDetector(),
    SensitiveDetector(),
]
