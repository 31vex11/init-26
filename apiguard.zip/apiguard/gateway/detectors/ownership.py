"""
OWNERSHIP detector  -  catches BOLA (Broken Object Level Authorization).

THIS IS THE HEADLINE. Read the comments carefully; this is what you'll be
asked to explain.

The attack: a logged-in user requests an object that isn't theirs by editing
an ID in the URL - GET /api/orders/1043 when 1043 belongs to someone else.
The request is 100% well-formed. There is no bad payload, no weird header.
A traditional firewall that scans request TEXT sees nothing wrong. You can
only catch this if you know WHO is asking (from the token) and look at WHAT
came back (the response body).

Two signals:

  Signal 1 - direct ownership mismatch:
    The response body contains an owner field (user_id / owner / customer_id).
    If that owner is not the caller's identity, this is a confirmed BOLA.
    Severity: critical. Recommended action: block. This is a hard match with
    real evidence - the caller's id AND the owner's id, side by side.

  Signal 2 - enumeration:
    Even without an owner field, a user pulling many DISTINCT object ids from
    one endpoint in a short window is walking the ID space (1042, 1043, 1044...).
    We track the set of ids each identity has hit per endpoint. Over a
    threshold in the window -> flag as enumeration. Severity: high, throttle.

OWASP: API1:2023 - Broken Object Level Authorization.
"""

import time

from common.helpers import RequestContext
from common.models import (Finding, SEVERITY_CRITICAL, SEVERITY_HIGH,
                           ACTION_BLOCK, ACTION_THROTTLE)
from .base import Detector

OWNER_FIELDS = ("user_id", "owner", "owner_id", "customer_id", "account_id")

# enumeration tuning
ENUM_WINDOW_SEC = 60
ENUM_DISTINCT_THRESHOLD = 5   # >5 distinct ids from one user in 60s = enumerating


def _find_owner(obj) -> str | None:
    """Look for an owner field anywhere in a (possibly nested) JSON body."""
    if isinstance(obj, dict):
        for f in OWNER_FIELDS:
            if f in obj and isinstance(obj[f], str):
                return obj[f]
        for v in obj.values():
            found = _find_owner(v)
            if found:
                return found
    elif isinstance(obj, list):
        for v in obj:
            found = _find_owner(v)
            if found:
                return found
    return None


class OwnershipDetector(Detector):
    name = "ownership"

    def __init__(self):
        # identity -> endpoint -> list of (timestamp, object_id_seen)
        self._history: dict[str, dict[str, list[tuple[float, str]]]] = {}

    def evaluate(self, ctx: RequestContext) -> Finding | None:
        # We only care about successful reads that returned a body.
        if ctx.status != 200 or ctx.response_json is None:
            return None
        if ctx.identity == "anonymous":
            return None

        # ---- Signal 1: direct ownership mismatch --------------------------
        owner = _find_owner(ctx.response_json)
        if owner and owner != ctx.identity:
            return Finding(
                detector=self.name,
                title="Cross-user data access (BOLA)",
                severity=SEVERITY_CRITICAL,
                owasp="API1:2023 Broken Object Level Authorization",
                evidence={
                    "caller_identity": ctx.identity,
                    "resource_owner": owner,
                    "path": ctx.path,
                    "explanation": (
                        f"{ctx.identity} accessed a resource owned by {owner}. "
                        f"The request was valid; the server never checked ownership."
                    ),
                },
                recommended_action=ACTION_BLOCK,
            )

        # ---- Signal 2: enumeration ----------------------------------------
        # Record the object id from the URL (last templated segment was {id}).
        obj_id = ctx.path.rstrip("/").split("/")[-1]
        now = time.time()
        per_ident = self._history.setdefault(ctx.identity, {})
        seen = per_ident.setdefault(ctx.endpoint, [])
        seen.append((now, obj_id))
        # drop anything older than the window
        seen[:] = [(t, i) for (t, i) in seen if now - t <= ENUM_WINDOW_SEC]
        distinct = {i for (_, i) in seen}

        if len(distinct) > ENUM_DISTINCT_THRESHOLD:
            return Finding(
                detector=self.name,
                title="Object enumeration",
                severity=SEVERITY_HIGH,
                owasp="API1:2023 Broken Object Level Authorization",
                evidence={
                    "caller_identity": ctx.identity,
                    "endpoint": ctx.endpoint,
                    "distinct_ids_in_window": len(distinct),
                    "window_seconds": ENUM_WINDOW_SEC,
                    "sample_ids": sorted(distinct)[:8],
                    "explanation": (
                        f"{ctx.identity} requested {len(distinct)} distinct objects "
                        f"from {ctx.endpoint} in {ENUM_WINDOW_SEC}s - walking the ID space."
                    ),
                },
                recommended_action=ACTION_THROTTLE,
            )
        return None
