"""
ABUSE detector  -  rate limiting + resource-consumption abuse.

Two signals:

  Signal 1 - request flood:
    A sliding window per identity (falling back to IP for anonymous callers).
    More than N requests in the window -> throttle. This catches brute force,
    credential stuffing volume, and general hammering.

  Signal 2 - oversized page request:
    A list endpoint called with ?limit=999999 is trying to scrape the whole
    dataset in one shot. We flag any limit above a sane cap.

OWASP: API4:2023 - Unrestricted Resource Consumption.
"""

import time

from common.helpers import RequestContext
from common.models import Finding, SEVERITY_MEDIUM, ACTION_THROTTLE
from .base import Detector

RATE_WINDOW_SEC = 10
RATE_MAX_REQUESTS = 15     # >15 requests / 10s from one caller = abuse
LIMIT_CAP = 1000           # ?limit above this is scraping


class AbuseDetector(Detector):
    name = "abuse"

    def __init__(self):
        # key (identity or ip) -> list of timestamps
        self._hits: dict[str, list[float]] = {}

    def evaluate(self, ctx: RequestContext) -> Finding | None:
        # Signal 2: oversized limit (cheap, check first)
        raw_limit = ctx.query.get("limit")
        if raw_limit is not None:
            try:
                if int(raw_limit) > LIMIT_CAP:
                    return Finding(
                        detector=self.name,
                        title="Oversized data request",
                        severity=SEVERITY_MEDIUM,
                        owasp="API4:2023 Unrestricted Resource Consumption",
                        evidence={
                            "requested_limit": int(raw_limit),
                            "allowed_cap": LIMIT_CAP,
                            "endpoint": ctx.endpoint,
                            "explanation": (
                                f"Caller requested limit={raw_limit}, far above the "
                                f"{LIMIT_CAP} cap - likely bulk scraping."
                            ),
                        },
                        recommended_action=ACTION_THROTTLE,
                    )
            except ValueError:
                pass

        # Signal 1: request flood
        key = ctx.identity if ctx.identity != "anonymous" else ctx.client_ip
        now = time.time()
        hits = self._hits.setdefault(key, [])
        hits.append(now)
        hits[:] = [t for t in hits if now - t <= RATE_WINDOW_SEC]

        if len(hits) > RATE_MAX_REQUESTS:
            return Finding(
                detector=self.name,
                title="Request rate abuse",
                severity=SEVERITY_MEDIUM,
                owasp="API4:2023 Unrestricted Resource Consumption",
                evidence={
                    "caller": key,
                    "requests_in_window": len(hits),
                    "window_seconds": RATE_WINDOW_SEC,
                    "limit": RATE_MAX_REQUESTS,
                    "explanation": (
                        f"{key} made {len(hits)} requests in {RATE_WINDOW_SEC}s "
                        f"(limit {RATE_MAX_REQUESTS})."
                    ),
                },
                recommended_action=ACTION_THROTTLE,
            )
        return None
