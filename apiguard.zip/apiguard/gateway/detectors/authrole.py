"""
AUTHROLE detector  -  broken authentication + broken function-level auth (BFLA).

Two related problems handled in one file because both are about the token:

  Signal 1 - weak/broken authentication (API2:2023):
    * alg:none in the JWT header -> an attacker has stripped the signature,
      a classic forgery trick. Critical.
    * missing exp claim -> token that never expires. Medium.
    (We intentionally do not verify signatures - see helpers.decode_jwt for why.)

  Signal 2 - broken function level authorization / BFLA (API5:2023):
    A caller whose role is not 'admin' touching an admin-only path. The token
    itself says role:customer, so we block the privilege escalation.

Note this detector reads the REQUEST (token + path), so it can fire BEFORE the
upstream call even happens. The proxy checks these findings early and can block
without ever forwarding the request.
"""

import time

from common.helpers import RequestContext, jwt_header
from common.models import (Finding, SEVERITY_CRITICAL, SEVERITY_MEDIUM,
                           SEVERITY_HIGH, ACTION_BLOCK)
from .base import Detector

ADMIN_PREFIXES = ("/admin",)  # paths only admins may touch


class AuthRoleDetector(Detector):
    name = "authrole"

    def evaluate(self, ctx: RequestContext) -> Finding | None:
        # ---- Signal 2 first: BFLA is the strongest, block early -----------
        if any(ctx.endpoint.startswith(p) for p in ADMIN_PREFIXES):
            if ctx.role != "admin":
                return Finding(
                    detector=self.name,
                    title="Privilege escalation (BFLA)",
                    severity=SEVERITY_HIGH,
                    owasp="API5:2023 Broken Function Level Authorization",
                    evidence={
                        "caller_identity": ctx.identity,
                        "caller_role": ctx.role,
                        "protected_path": ctx.endpoint,
                        "explanation": (
                            f"Role '{ctx.role}' attempted to access admin-only "
                            f"path {ctx.endpoint}."
                        ),
                    },
                    recommended_action=ACTION_BLOCK,
                )

        # ---- Signal 1: token weaknesses -----------------------------------
        if ctx.token:
            header = jwt_header(ctx.token)
            if str(header.get("alg", "")).lower() == "none":
                return Finding(
                    detector=self.name,
                    title="Unsigned token (alg:none)",
                    severity=SEVERITY_CRITICAL,
                    owasp="API2:2023 Broken Authentication",
                    evidence={
                        "alg": header.get("alg"),
                        "explanation": (
                            "Token header declares alg:none - the signature has "
                            "been stripped, allowing forgery."
                        ),
                    },
                    recommended_action=ACTION_BLOCK,
                )
            exp = ctx.claims.get("exp")
            if exp is None and ctx.identity != "anonymous":
                return Finding(
                    detector=self.name,
                    title="Token without expiry",
                    severity=SEVERITY_MEDIUM,
                    owasp="API2:2023 Broken Authentication",
                    evidence={
                        "explanation": "Token has no exp claim; it never expires.",
                    },
                )
            if isinstance(exp, (int, float)) and exp < time.time():
                return Finding(
                    detector=self.name,
                    title="Expired token accepted",
                    severity=SEVERITY_HIGH,
                    owasp="API2:2023 Broken Authentication",
                    evidence={
                        "exp": exp, "now": int(time.time()),
                        "explanation": "Token exp is in the past but was accepted.",
                    },
                    recommended_action=ACTION_BLOCK,
                )
        return None
