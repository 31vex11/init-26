"""
The detector contract.

Every detector is a class with ONE method: evaluate(ctx). It looks at the
request context and returns a Finding if something is wrong, or None if the
request looks fine. That's the entire interface. Adding a new detector means
writing one class and adding it to the list in registry.py - nothing else
changes. This is what 'modular design' on the rubric means.
"""

from common.helpers import RequestContext
from common.models import Finding


class Detector:
    """Base class. Subclasses override name and evaluate()."""
    name = "base"

    def evaluate(self, ctx: RequestContext) -> Finding | None:
        raise NotImplementedError
