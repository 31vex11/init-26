"""
SENSITIVE detector  -  catches excessive data exposure in RESPONSES.

The insight most teams miss: this vulnerability does not exist in the request
at all. The request is a normal GET. The problem is what the server *returns* -
extra fields the UI never needed (password_hash, phone, salary...). To catch it
you must inspect the response body, which almost no tool does.

Two signals:

  Signal 1 - known-sensitive KEYS:
    Scan response JSON keys against a list of dangerous field names.
    Any hit -> finding, and the recommended action is REDACT (not block):
    the request still succeeds, but the secret value is replaced with
    [REDACTED]. This is the best thing to show a judge: the app keeps working
    while the leak is stopped live.

  Signal 2 - sensitive VALUE patterns:
    Some leaks aren't in the key name. Regex the values for things that look
    like emails, phone numbers, or card numbers, in case a field is named
    innocuously.

OWASP: API3:2023 - Broken Object Property Level Authorization
       (formerly 'Excessive Data Exposure').
"""

import re

from common.helpers import RequestContext
from common.models import Finding, SEVERITY_HIGH, ACTION_REDACT
from .base import Detector

# field names that should almost never leave the server
SENSITIVE_KEYS = {
    "password", "passwd", "pwd", "password_hash", "hash", "secret",
    "token", "api_key", "apikey", "private_key", "ssn", "aadhaar",
    "pan", "salary", "credit_card", "card_number", "cvv", "phone",
}

# endpoints where returning a token/secret is the intended behaviour
AUTH_ENDPOINTS = {"/login", "/auth/login", "/oauth/token", "/token"}

# value patterns
PATTERNS = {
    "email": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    "card":  re.compile(r"\b(?:\d[ -]?){13,16}\b"),
    "phone": re.compile(r"\+?\d[\d -]{8,14}\d"),
}


def _scan_keys(obj, hits: set[str]):
    """Walk the JSON and collect any sensitive key names present."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k.lower() in SENSITIVE_KEYS:
                hits.add(k)
            _scan_keys(v, hits)
    elif isinstance(obj, list):
        for v in obj:
            _scan_keys(v, hits)


class SensitiveDetector(Detector):
    name = "sensitive"

    def evaluate(self, ctx: RequestContext) -> Finding | None:
        if ctx.status != 200 or ctx.response_json is None:
            return None

        # Auth endpoints are SUPPOSED to return a token - that's their job.
        # Redacting the login response would break every downstream call, so we
        # exempt them. (A real deployment configures this exempt-list per API.)
        if ctx.endpoint in AUTH_ENDPOINTS:
            return None

        # Signal 1: sensitive keys
        key_hits: set[str] = set()
        _scan_keys(ctx.response_json, key_hits)

        # Signal 2: sensitive value patterns (only if no key hit, to keep it clean)
        value_hits: list[str] = []
        if not key_hits:
            text = str(ctx.response_json)
            for label, rx in PATTERNS.items():
                if rx.search(text):
                    value_hits.append(label)

        if not key_hits and not value_hits:
            return None

        return Finding(
            detector=self.name,
            title="Sensitive data in response",
            severity=SEVERITY_HIGH,
            owasp="API3:2023 Excessive Data Exposure",
            evidence={
                "leaked_fields": sorted(key_hits),
                "matched_patterns": value_hits,
                "path": ctx.path,
                "explanation": (
                    "Response body contains sensitive fields the client "
                    "should not receive: " + ", ".join(sorted(key_hits) or value_hits)
                ),
            },
            recommended_action=ACTION_REDACT,
        )


def redact_body(obj):
    """
    Replace the VALUES of sensitive keys with [REDACTED], recursively,
    leaving structure intact so the client still gets a valid response.
    The policy engine calls this when the action is REDACT.
    """
    if isinstance(obj, dict):
        return {
            k: ("[REDACTED]" if k.lower() in SENSITIVE_KEYS else redact_body(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [redact_body(v) for v in obj]
    return obj
