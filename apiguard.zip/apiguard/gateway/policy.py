"""
The policy engine - turns findings into a DECISION.

Detectors only *observe* and recommend. The policy engine decides what
actually happens, and it's where we answer the rubric's explicit question:
'how do you balance protection against false positives and friction?'

Answer = MODES. The same detectors run in every mode; only the consequence
changes:

  observe  - detect and log, never act. Use this to learn/tune with zero risk.
  warn     - detect, log, mark the event, but still let traffic through.
  enforce  - detect and actually act (block / redact / throttle). Production.

Plus a per-identity OVERRIDE list: an operator who decides a finding is a
false positive can allow-list that identity from the dashboard, and the engine
will downgrade its actions to allow. That is the human-in-the-loop 'review or
override' the dashboard requirement asks for.
"""

from common.models import (Finding, ACTION_ALLOW, ACTION_REDACT,
                           ACTION_THROTTLE, ACTION_BLOCK)

# strength ordering so we can pick the most severe recommended action
_STRENGTH = {ACTION_ALLOW: 0, ACTION_THROTTLE: 1, ACTION_REDACT: 2, ACTION_BLOCK: 3}


class Policy:
    def __init__(self, mode: str = "enforce"):
        self.mode = mode                     # observe | warn | enforce
        self.overrides: set[str] = set()     # identities the operator trusts

    def set_mode(self, mode: str):
        if mode in ("observe", "warn", "enforce"):
            self.mode = mode

    def add_override(self, identity: str):
        self.overrides.add(identity)

    def clear_override(self, identity: str):
        self.overrides.discard(identity)

    def decide(self, findings: list[Finding], identity: str) -> str:
        """
        Given all findings for a request, return the action to take RIGHT NOW,
        already adjusted for the current mode and any override.
        """
        if not findings:
            return ACTION_ALLOW

        # strongest recommendation across all findings
        strongest = max(findings, key=lambda f: _STRENGTH[f.recommended_action])
        intended = strongest.recommended_action

        # override: operator has decided this caller is fine
        if identity in self.overrides:
            return ACTION_ALLOW

        # mode gates the consequence
        if self.mode == "observe":
            return ACTION_ALLOW            # detect only
        if self.mode == "warn":
            return ACTION_ALLOW            # flagged, but traffic passes
        return intended                    # enforce: do the real thing
