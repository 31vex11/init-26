"""
The VULNERABLE target API - a tiny online shop.

This is the app our proxy protects. It is *intentionally* insecure so we
have real vulnerabilities to catch. Every flaw here maps to an OWASP API
Top 10 category, and to one of our detectors:

  * /api/orders/{id}   leaks other users' orders   -> BOLA        (ownership detector)
  * /api/me            returns password_hash, phone -> data exposure (sensitive detector)
  * /admin/users       no role check                -> BFLA        (role detector)
  * every list endpoint honours ?limit=999999       -> abuse       (rate detector)

Login is faked: POST /login with a username returns a JWT for that user.
The JWT is unsigned-ish (we build it by hand) - fine, because our proxy
only decodes, never verifies. Run this on port 9000.
"""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import base64
import json

app = FastAPI(title="Vulnerable Shop")

# ---- fake database -----------------------------------------------------------
# Note the secret fields (password_hash, phone) sitting right next to the
# harmless ones. A real app leaks these by serialising the whole DB row.
USERS = {
    "user_4021": {"id": "user_4021", "name": "Aisha Khan",   "role": "customer",
                  "email": "aisha@example.com", "phone": "+91-98200-11111",
                  "password_hash": "$2b$12$abcAISHAhashvalue000000"},
    "user_4088": {"id": "user_4088", "name": "Rohan Mehta",  "role": "customer",
                  "email": "rohan@example.com", "phone": "+91-98200-22222",
                  "password_hash": "$2b$12$abcROHANhashvalue0000000"},
    "admin_1":   {"id": "admin_1",   "name": "Site Admin",   "role": "admin",
                  "email": "admin@example.com", "phone": "+91-98200-00000",
                  "password_hash": "$2b$12$abcADMINhashvalue0000000"},
}

ORDERS = {
    "1042": {"id": "1042", "user_id": "user_4021", "item": "Wireless mouse",  "total": 799},
    "1043": {"id": "1043", "user_id": "user_4088", "item": "Mechanical keyboard", "total": 4499},
    "1044": {"id": "1044", "user_id": "user_4088", "item": "USB-C hub",       "total": 1299},
    "1045": {"id": "1045", "user_id": "user_4021", "item": "Laptop stand",    "total": 1599},
}


# ---- fake login: hand-build an unsigned JWT ----------------------------------
def _b64(obj) -> str:
    raw = json.dumps(obj, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def make_token(username: str) -> str:
    user = USERS.get(username, {"id": username, "role": "customer"})
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {"sub": user["id"], "role": user["role"]}
    # signature left as a dummy - our proxy doesn't check it, and neither does
    # this toy server. That's the whole point.
    return f"{_b64(header)}.{_b64(payload)}.dummysignature"


def whoami(request: Request) -> str:
    """Read the sub claim from the Authorization header, if present."""
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        return ""
    try:
        payload = auth.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        return json.loads(base64.urlsafe_b64decode(payload)).get("sub", "")
    except Exception:
        return ""


# ---- endpoints ---------------------------------------------------------------
@app.post("/login")
async def login(request: Request):
    body = await request.json()
    username = body.get("username", "user_4021")
    return {"token": make_token(username), "user": username}


@app.get("/api/me")
async def me(request: Request):
    # VULN (excessive data exposure): returns the ENTIRE user record,
    # password_hash and phone included, even though a UI only needs name/email.
    who = whoami(request)
    user = USERS.get(who)
    if not user:
        return JSONResponse({"error": "not logged in"}, status_code=401)
    return user


@app.get("/api/orders/{order_id}")
async def get_order(order_id: str, request: Request):
    # VULN (BOLA): checks you're logged in, but NOT that the order is yours.
    who = whoami(request)
    if not who:
        return JSONResponse({"error": "not logged in"}, status_code=401)
    order = ORDERS.get(order_id)
    if not order:
        return JSONResponse({"error": "no such order"}, status_code=404)
    return order  # <-- hands over ANY order to ANY logged-in user


@app.get("/api/orders")
async def list_orders(request: Request, limit: int = 20):
    # VULN (abuse): honours any limit the caller asks for, enabling scraping.
    who = whoami(request)
    if not who:
        return JSONResponse({"error": "not logged in"}, status_code=401)
    items = list(ORDERS.values())[:limit]
    return {"orders": items, "count": len(items)}


@app.get("/admin/users")
async def admin_users(request: Request):
    # VULN (BFLA): admin-only data, but there is NO role check at all.
    return {"users": list(USERS.values())}


@app.get("/health")
async def health():
    return {"ok": True}
