"""
Attack simulator - the demo engine.

Runs a scripted sequence of realistic traffic through the PROXY (port 8080),
so judges watch the dashboard light up live. It sends normal traffic first,
then each attack in turn, printing what it expects to happen.

Run it two ways:
    python -m attack.simulate            # run the whole script once
    python -m attack.simulate --loop     # keep going (nice background demo)

Point everything at the proxy, never the target directly - the whole point is
that traffic goes THROUGH the guard.
"""

import sys
import time
import httpx

PROXY = "http://127.0.0.1:8080"


def login(username: str) -> str:
    r = httpx.post(f"{PROXY}/login", json={"username": username})
    return r.json()["token"]


def step(label: str, expect: str):
    print(f"\n=== {label}")
    print(f"    expect: {expect}")


def run_once():
    # ---- 1. normal, legitimate traffic (should all be ALLOWED) -----------
    step("Legitimate traffic", "all allowed, no findings")
    aisha = login("user_4021")
    ha = {"Authorization": f"Bearer {aisha}"}
    print("   ", httpx.get(f"{PROXY}/api/orders/1042", headers=ha).status_code,
          "Aisha reads her own order 1042")
    print("   ", httpx.get(f"{PROXY}/api/orders/1045", headers=ha).status_code,
          "Aisha reads her own order 1045")
    time.sleep(0.4)

    # ---- 2. BOLA: Aisha reads Rohan's order ------------------------------
    step("BOLA - cross-user access", "BLOCKED (critical) - order 1043 is Rohan's")
    r = httpx.get(f"{PROXY}/api/orders/1043", headers=ha)
    print("   ", r.status_code, r.text[:80])
    time.sleep(0.4)

    # ---- 3. Excessive data exposure --------------------------------------
    step("Data exposure - /api/me", "REDACTED - password_hash & phone hidden")
    r = httpx.get(f"{PROXY}/api/me", headers=ha)
    print("   ", r.status_code, r.text[:160])
    time.sleep(0.4)

    # ---- 4. BFLA: customer hits admin ------------------------------------
    step("BFLA - privilege escalation", "BLOCKED - customer role on /admin/users")
    r = httpx.get(f"{PROXY}/admin/users", headers=ha)
    print("   ", r.status_code, r.text[:80])
    time.sleep(0.4)

    # ---- 5. Enumeration: walk the ID space -------------------------------
    step("Enumeration - walking order IDs", "THROTTLE finding after ~5 distinct ids")
    for oid in range(1042, 1050):
        httpx.get(f"{PROXY}/api/orders/{oid}", headers=ha)
    print("    walked 1042..1049")
    time.sleep(0.4)

    # ---- 6. Oversized scrape ---------------------------------------------
    step("Scraping - ?limit=999999", "THROTTLE - oversized data request")
    r = httpx.get(f"{PROXY}/api/orders?limit=999999", headers=ha)
    print("   ", r.status_code)
    time.sleep(0.4)

    # ---- 7. Rate flood ---------------------------------------------------
    step("Rate abuse - burst of requests", "THROTTLE after 15 in 10s")
    for _ in range(20):
        httpx.get(f"{PROXY}/api/orders/1042", headers=ha)
    print("    sent 20 rapid requests")

    print("\nDone. Open the dashboard at", PROXY, "to review findings.")


if __name__ == "__main__":
    loop = "--loop" in sys.argv
    if loop:
        while True:
            run_once()
            time.sleep(3)
    else:
        run_once()
