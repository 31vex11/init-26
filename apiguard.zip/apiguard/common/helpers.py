"""
Small shared utilities. Two of these are load-bearing:

1. decode_jwt  -> reads WHO is making a request (the whole project depends on this)
2. templatize  -> turns /api/orders/1043 into /api/orders/{id} so we can group
                  requests by endpoint instead of treating every ID as unique
"""

import base64
import json
import re
from dataclasses import dataclass, field
from typing import Any


def _b64url_decode(segment: str) -> bytes:
    """JWT uses base64url without padding. Add the padding back, then decode."""
    padding = "=" * (-len(segment) % 4)
    return base64.urlsafe_b64decode(segment + padding)


def decode_jwt(token: str) -> dict[str, Any]:
    """
    Read the claims out of a JWT WITHOUT verifying the signature.

    A JWT is three base64 chunks joined by dots:  header.payload.signature
    The payload is just JSON. We only care about the payload, and base64 is
    reversible by anyone, so no secret key is needed. This is exactly why an
    attacker can read (and, on a badly-built server, tamper with) a token -
    and exactly how our proxy learns who is calling.

    We deliberately DO NOT verify the signature here. That's a documented
    trade-off in the README: for a prototype, knowing the claimed identity is
    enough to demonstrate authorization detection. A production build would
    verify against the issuer's key.

    Returns {} if anything looks wrong, so callers can treat that as anonymous.
    """
    if not token:
        return {}
    token = token.strip()
    if token.lower().startswith("bearer "):
        token = token[7:]
    parts = token.split(".")
    if len(parts) != 3:
        return {}
    try:
        payload = json.loads(_b64url_decode(parts[1]))
        if isinstance(payload, dict):
            return payload
    except Exception:
        pass
    return {}


def jwt_header(token: str) -> dict[str, Any]:
    """Same idea, but the FIRST chunk. We need it to spot `alg: none` tokens."""
    if not token:
        return {}
    token = token.strip()
    if token.lower().startswith("bearer "):
        token = token[7:]
    parts = token.split(".")
    if len(parts) < 1:
        return {}
    try:
        h = json.loads(_b64url_decode(parts[0]))
        return h if isinstance(h, dict) else {}
    except Exception:
        return {}


# A path segment is "an ID" if it's all digits, a UUID, or a long hex blob.
_INT = re.compile(r"^\d+$")
_UUID = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
                   r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
_HEX = re.compile(r"^[0-9a-fA-F]{16,}$")


def templatize(path: str) -> str:
    """
    /api/orders/1043      -> /api/orders/{id}
    /api/users/42/orders  -> /api/users/{id}/orders

    Why: we want to say "the /api/orders/{id} endpoint got 200 requests",
    not treat order 1043 and order 1044 as two different endpoints. Every
    per-endpoint thing we do (rate limits, baselines, the endpoint list on
    the dashboard) keys off this templated form.
    """
    out = []
    for seg in path.split("/"):
        if _INT.match(seg) or _UUID.match(seg) or _HEX.match(seg):
            out.append("{id}")
        else:
            out.append(seg)
    return "/".join(out) or "/"


@dataclass
class RequestContext:
    """
    Everything the detectors need to look at, gathered in one place so each
    detector has a tidy object to read instead of digging through raw request
    internals. The proxy builds one of these per request and passes it around.
    """
    method: str
    path: str
    endpoint: str
    client_ip: str
    headers: dict[str, str]
    query: dict[str, str]

    # filled in from the token
    identity: str = "anonymous"
    role: str = "anonymous"
    token: str = ""
    claims: dict[str, Any] = field(default_factory=dict)

    # filled in after the upstream API responds
    status: int = 0
    response_json: Any = None   # parsed JSON body, or None if not JSON
    response_text: str = ""     # raw text, for the rare non-JSON case
