"""
Shared data shapes for the whole project.

Everything in APIGuard revolves around ONE object: the Event.
A detector looks at a request/response and, if it finds something,
returns a Finding. The proxy bundles the request + any findings + the
action it took into an Event, and the dashboard renders Events.

Get this object right and the rest of the code is easy, because every
module speaks the same language. This is the single most important file.
"""

from dataclasses import dataclass, field, asdict
from typing import Any
import time
import uuid


# The severity of a finding. Plain strings so the dashboard can colour them.
SEVERITY_LOW = "low"
SEVERITY_MEDIUM = "medium"
SEVERITY_HIGH = "high"
SEVERITY_CRITICAL = "critical"

# What the policy engine decided to DO about an event.
ACTION_ALLOW = "allow"        # let it through untouched
ACTION_REDACT = "redact"      # let it through but strip secret fields from the body
ACTION_THROTTLE = "throttle"  # let it through but mark the caller as abusive
ACTION_BLOCK = "block"        # stop it, return an error to the client


@dataclass
class Finding:
    """
    One thing a detector noticed. This is the 'why' behind every alert,
    and it's what earns marks on the 'transparent alert triggers' criterion.

    Always fill in `evidence` with the concrete thing you saw - the field
    name, the value, the count. Never just say 'suspicious'. Show the receipt.
    """
    detector: str          # which detector fired, e.g. "ownership"
    title: str             # short human label, e.g. "Cross-user data access (BOLA)"
    severity: str          # one of the SEVERITY_* constants
    owasp: str             # the OWASP API category, e.g. "API1:2023 BOLA"
    evidence: dict[str, Any] = field(default_factory=dict)  # the receipt
    recommended_action: str = ACTION_ALLOW  # what this detector thinks should happen


@dataclass
class Event:
    """
    A full record of one request passing through the proxy: who asked,
    what they asked for, what came back, what we found, and what we did.
    The dashboard is basically a live list of these.
    """
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    ts: float = field(default_factory=time.time)

    # request side
    method: str = "GET"
    path: str = "/"                 # raw path, e.g. /api/orders/1043
    endpoint: str = "/"            # templated path, e.g. /api/orders/{id}
    client_ip: str = "-"
    identity: str = "anonymous"    # who the token said this is, e.g. "user_4021"
    role: str = "anonymous"        # role from the token, e.g. "customer"

    # response side
    status: int = 0
    latency_ms: float = 0.0

    # verdict
    findings: list[Finding] = field(default_factory=list)
    action: str = ACTION_ALLOW
    mode: str = "enforce"          # which mode we were in when we decided

    def to_dict(self) -> dict:
        """Turn this into plain JSON the dashboard can fetch."""
        d = asdict(self)
        return d
