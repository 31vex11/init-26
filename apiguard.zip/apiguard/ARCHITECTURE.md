# Architecture

## Design goal

Sit in the request path, make a security decision per request in single-digit
milliseconds of added latency, and explain every decision with concrete
evidence. Everything below serves those three things.

## Data flow

```
                    ┌─────────────────────────────────────────────┐
   client ─────────▶│                APIGuard proxy               │──────▶ target API
                    │                                             │◀──────
                    │  1. decode token        → identity, role    │
                    │  2. build RequestContext                    │
                    │  3. request-phase detectors → can block     │
                    │  4. forward upstream (httpx), time it       │
                    │  5. parse response body                     │
                    │  6. response-phase detectors → findings     │
                    │  7. policy.decide(findings, mode, overrides)│
                    │  8. act: allow / redact / throttle / block  │
                    │  9. record Event                            │
                    └──────────────────┬──────────────────────────┘
                                       │ /__guard/* JSON
                                       ▼
                                 console (polls 1s)
```

The two-phase detection matters. Some checks (bad token, wrong role, oversized
`?limit`) can be made from the request alone, so the proxy can **block before
forwarding** and never touch the upstream. Others (cross-user data, secret
fields) require the response body, so they run after the upstream call. Both
phases contribute to the same list of findings.

## The core data model (`common/models.py`)

Everything speaks in two objects:

- **`Finding`** — one thing a detector noticed: which detector, a title, a
  severity, the OWASP category, an `evidence` dict (the receipt), and a
  recommended action. The `evidence` dict is deliberately open-ended so each
  detector can show the specific fields that matter.
- **`Event`** — one request's full story: who, what, the response status and
  latency, all findings, and the action taken. The console is a live list of
  these.

Designing this contract first is what let three components be built in parallel:
detectors produce `Finding`s, the proxy assembles `Event`s, the console renders
them. No component needs to know the internals of another.

## Detector interface (`gateway/detectors/base.py`)

```python
class Detector:
    name = "..."
    def evaluate(self, ctx: RequestContext) -> Finding | None: ...
```

That's the whole contract. A detector reads the `RequestContext` (request fields
plus, in the response phase, the parsed body) and returns a `Finding` or `None`.
State that must persist across requests (rate windows, enumeration history) lives
on the detector instance, which is created once in the registry.

### Why each detector works

**Ownership (BOLA) — `ownership.py`.** Two signals. The strong one compares the
caller's identity (`sub` from the token) against any owner field found in the
response body (`user_id`, `owner`, `customer_id`). A mismatch is a *confirmed*
authorization break with hard evidence — the two IDs side by side — so it blocks.
The second signal counts distinct object IDs a caller retrieves from one endpoint
in a rolling 60s window; walking the ID space is enumeration even when each
individual object might arguably be theirs.

**Sensitive (data exposure) — `sensitive.py`.** Scans response JSON keys against
a set of dangerous field names, and (as a fallback) values against email/card/
phone regexes. The action is *redact*, not block: the request still succeeds, the
secret is replaced with `[REDACTED]`. Auth endpoints are exempt because issuing a
token is their job.

**Auth + role — `authrole.py`.** Reads the token header and claims. `alg:none`
means a stripped signature (forgery) → block. Missing/expired `exp` → flag/block.
And BFLA: a non-admin role touching an `/admin/*` path → block. These are all
request-phase, so they short-circuit before the upstream call.

**Abuse — `abuse.py`.** A sliding window per identity (falling back to IP for
anonymous callers) catches floods; an oversized `?limit` catches bulk scraping.
Action is throttle.

## Policy engine (`gateway/policy.py`)

Detectors only *recommend*; the policy engine *decides*. It takes the strongest
recommended action across all findings, then applies two gates:

- **Mode** — `observe` and `warn` downgrade every action to allow (detect-only /
  flag-only); `enforce` carries out the real action. This is the false-positive
  and friction control the brief asks about: deploy in observe, watch the feed,
  then enforce once tuned.
- **Overrides** — an operator-maintained allow-list of trusted identities whose
  actions are downgraded to allow. The human-in-the-loop escape hatch.

## Why a reverse proxy

The brief requires acting **in real time**. A scanner that runs afterwards can
report but cannot block. Being in the request path is the only architecture that
can prevent, not just detect. The proxy is transport-agnostic: it forwards any
method, any path, so it protects an unmodified target with zero changes to that
target's code.

## Performance

The proxy adds one token decode (base64, no crypto), a handful of dict lookups
and regex scans, and one JSON parse of the response — all O(size of body). The
per-request `latency_ms` shown on every row is total round-trip including the
upstream; the guard's own overhead is a small fraction of it and is visible by
comparing against a direct call.

## Extending it

- **New detector**: add a class in `gateway/detectors/`, register it in
  `__init__.py`. Done.
- **Persistent storage**: replace the `deque` and `_record()` in `proxy.py` with
  a database writer; nothing else depends on the store.
- **Real signature verification**: add a verify step in `helpers.decode_jwt`
  keyed on the issuer's public key.
- **Protect a different API**: set the `UPSTREAM` environment variable to its URL.
